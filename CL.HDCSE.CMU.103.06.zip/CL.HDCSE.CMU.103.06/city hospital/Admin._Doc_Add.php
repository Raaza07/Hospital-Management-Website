
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator Doctor Add.php</title>

<link rel="stylesheet" href="regCss.css">



</head>


<body>


<center>


 <div class="image">
 <img src="images/22.jpeg"/>

 </div>
 
 <div class="title">
 
 <h1>Welcome Administrator</h1>
 
  </div>
 
 <div class="sentences">
 
 
  <h2>Add Doctor Details</h2>
  <br />
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafc </p>
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas </p>
 <p>cjasafcsackas jkc asj cjas cjas cja casj cjas casj casj ca </p>

  </div>
  <br />
   	<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');//important

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>
    <br />


 
		<table border="4">
			<thead>
				
                <tr>
					<th>Doctor Name</th>
					<td>
                  <form name="form" method="post" action="">
                     <input type="text" name="Doctor" id="Doctor" />
                    
                    </td>
				</tr>
                                            
                <tr>
                
					<th>Specialization </th>
                    
					<td>
                    
                    <select id="Specialization" name="Specialization">
                    
                    <option value="Specialty doctors ">Specialty doctors </option>
                    <option value="Allergists">Allergists</option>
                    <option value="Dermatologists">Dermatologists</option>
                    <option value="Ophthalmologists">Ophthalmologists</option>
                    <option value="Cardiologists">Cardiologists</option>
                    <option value="Endocrinologists">Endocrinologists</option>
                    <option value="Psychiatrists">Psychiatrists</option>
                    
                          </select>                
                    
                    </td>
				</tr>
			</thead>
			<tbody>
            
			    <tr>
					<th>Doctor Email</th>
					<td>
                    
          <input type="text" name="Email" id="Email">
                    
                    
                    </td>
				</tr>
                
				<tr>
					<th> Age</th>
			        			<td>
                    
          <input type="text" name="Age" id="Age">
                    
                    
                    </td>        
        
          
				</tr>
                
                
				<tr>
					<th>Contact</th>
					              	<td>
                    
          <input type="text" name="Contact" id="Contact">
                    
                    
                    </td>           
                    
				</tr>
                
                <tr>
					<th>Branch</th>
					<td>
                    
                    <select id="Branch" name="Branch">
                    
                      
                    <option value="Jaffna">Jaffna</option>
                    <option value="Galle">Galle</option>
                    <option value="Kurunagala">Kurunagala</option>
                   
                    
                          </select>  
                    
                    
                    </td>
				</tr>
                
                  <tr>
					<th>Address</th>
					<td>
                    
          <input type="text" name="Address" id="Address">
                    
                    
                    </td>
				</tr>
                
                         <tr>
					<th>Fees</th>
					<td>
                    
          <input type="text" name="Fees" id="Fees">
                    
                    
                    </td>
				</tr>
                
                    <tr>
					<th>Username</th>
					<td>
                    
          <input type="text" name="Username" id="Username">
                    
                    
                    </td>
				</tr>
                    <tr>
					<th>Password</th>
					<td>
                    
          <input type="text" name="Password" id="Password">
                    
                    
                    </td>
				</tr>
                
                
				<tr id="btna">
				<td colspan="2"><input type="submit" name="submit" id="btn" value="Add details" onclick="AddRow()"></td>
				</tr>
                
                <tr id="btna">
				<td colspan="2"><input type="reset" name="reset" id="btn" value="Clear details" onclick="AddRow()"></td>
				</tr>
                
			</tbody>
		</table>
     
     </form>
      <br />
     <?php
     
     if(isset($_POST['submit'])){
	
	

   $Doctor = mysqli_real_escape_string($conn, $_POST['Doctor']);
   $Specialization = mysqli_real_escape_string($conn, $_POST['Specialization']);
   $Email = mysqli_real_escape_string($conn, $_POST['Email']);  
   $Age = mysqli_real_escape_string($conn, $_POST['Age']);
   $Contact = mysqli_real_escape_string($conn, $_POST['Contact']);
   $Branch = mysqli_real_escape_string($conn, $_POST['Branch']);
   $Address = mysqli_real_escape_string($conn, $_POST['Address']);
   $Fees = mysqli_real_escape_string($conn, $_POST['Fees']);
     $Username = mysqli_real_escape_string($conn, $_POST['Username']);
	   $Password = mysqli_real_escape_string($conn, $_POST['Password']);
  
   

 $insert = "INSERT INTO doctor(doctor_name, specialization, email, age	,contact,branch,address,fees,username,password) VALUES('$Doctor','$Specialization','$Email','$Age','$Contact','$Branch','$Address','$Fees','$Username','$Password')";
		 
         $result=mysqli_query($conn, $insert);
		 
		 if($result){
			echo"<font color='#009900'> Doctor Details Added Succesfully ";//important
	        echo"<br/>";
			echo '<script type="text/javascript"> alert("Doctor Details Added  Succesfully ") </script>';
		 }
		 else{
			echo '<script type="text/javascript"> alert("Doctor Details Added  Unuccesfully") </script>';//important
			print"<font color='#FF0000'>Error    :  Doctor Details Added Unsuccesfully  !!!!!!!! ";
			echo"<br/>";
		 }
	}
		 
         



?>

     
     
     
       <a href="Admin_home.html">
<button type="button" name="back" class="back"> back </button>
</a>
           
        
	</center>
    </div>
    
</body>
</html>