



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
 
            <?php
				
				//Patient Login part.......				
				
				
				if(isset($_POST['submit'])){
					
					if(empty($_POST['username']) ||empty($_POST['password'])){
							echo"please fill the blanks ";
						
					}
					else{
					
					
					
					
                        $username=mysqli_real_escape_string($conn, $_POST['username']);						
						$password=mysqli_real_escape_string($conn, $_POST['password']);						
						
						$sql="SELECT * from register Where username='$username' AND password='$password' LIMIT 1";
						$result=mysqli_query($conn,$sql);
						
				if(mysqli_num_rows($result)==1){
					
					echo"USER login Succesfully ";
					header("location:Patient_home.html");
					
										
				}
				else{
						print"<font color='#FF0000'> please check your username or password!!!!!!!! ";
				
						
						echo '<script type="text/javascript"> alert("Login Unsuccessfully") </script>';
				}
				
					}
					
				}
				
				//Doctor Login part.......				
				
				if(isset($_POST['btn_doc'])){
					
					if(empty($_POST['username']) ||empty($_POST['password'])){
						
							echo"please fill in the blanks ";
						
					}
					else{
						
						$username=mysqli_real_escape_string($conn, $_POST['username']);						
						$password=mysqli_real_escape_string($conn, $_POST['password']);
						
					$sql="SELECT * from doctor Where username='$username' AND password='$password' LIMIT 1";
						$result=mysqli_query($conn,$sql);
						
				if(mysqli_num_rows($result)==1){
					
					echo"USER login Succesfully ";
					header("location:Dcotor_home.html");
					
										
				}
				else{
						print"<font color='#FF0000'> please check your username or password!!!!!!!! ";
				
						
						echo '<script type="text/javascript"> alert("Login Unsuccessfully") </script>';
				}
				
					}
					
				}
				
				
				//Admin Login part.......				
				
				if(isset($_POST['btn_adm'])){
					
					if(empty($_POST['username']) ||empty($_POST['password'])){
						
							echo"please fill in the blanks ";
						
					}
					else{
						
						$username=mysqli_real_escape_string($conn, $_POST['username']);						
						$password=mysqli_real_escape_string($conn, $_POST['password']);
						
						if($username=="admin" && $password=="123" ){
							
					echo"USER login Succesfully ";
					header("location:Admin_home.html");
					
						}
						else
						{
                       print"<font color='#FF0000'> please check your username or password!!!!!!!! ";
						
						echo '<script type="text/javascript"> alert("Login Unsuccessfully") </script>';
						
						}
					}
					
				}
				
				
				
				
?>

</body>
</html>
</body>
</html>