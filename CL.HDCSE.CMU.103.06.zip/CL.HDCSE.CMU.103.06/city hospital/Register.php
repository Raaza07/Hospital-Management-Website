<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="regCss.css" />
</head>


<body>
<center>






 <div class="image">
 <img src="images/22.jpeg" />
 
 </div>
 

 
 <h2>Patient Register</h2>
 

 
 <div class="sentences">
 
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafcsackas  </p>
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafcsackas </p>
 <p>cjasafcsackas jkc asj cjas cjas cja casj cjas casj casj ca </p>

  </div>
  <br />
  
  
              	<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');//important

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>
   
  <br />

<div class="card-container">


 <div class="tab1">
 
 
 	<form name="form"  method="post" action="">
		<table border="4">
			<thead>
				
                <tr>
					<th>Patient Name</th>
					<td>
                    
                   <input type="text" name="Patientname" id="Patientname">
                    
                    </td>
				</tr>
                                            
                <tr>
                
					<th>Gender </th>
                    
					<td>
                    
                  <input type="text" name="PatientGender" id="PatientGender">            
                    
                    </td>
				</tr>
			</thead>
			<tbody>
            <tr>
					<th>Patient Age</th>
			        			<td>
                    
          <input type="text" name="PatientAge" id="PatientAge">
                    
                    
                    </td>        
        
          
				</tr>
                
			    <tr>
					<th>Patient Email</th>
					<td>
                    
          <input type="text" name="PatientEmail" id="PatientEmail">
                    
                    
                    </td>
				</tr>
                
				
                
                
				<tr>
					<th>Patient Contact</th>
					              	<td>
                    
          <input type="text" name="PatientContact" id="PatientContact">
                    
                    
                    </td>           
                    
				</tr>
                
                
                  <tr>
					<th>Patient Address</th>
					<td>
                    
          <input type="text" name="PatientAddress" id="PatientAddress">
                    
                    
                    </td>
				</tr>
                
                 <tr>
					<th>Patient blood Group</th>
					<td>
                    
          <input type="text" name="blood_Group" id="blood_Group">
                    
                    
                    </td>
				</tr>
                
                
                
                
                         <tr>
					<th>Username</th>
					<td>
                    
          <input type="text" name="username" id="username">
                    
                    
                    </td>
				</tr>
                     <tr>
					<th>password</th>
					<td>
                    
          <input type="password" name="password" id="password">
                    
                    
                    </td>

                
				<tr id="btna">
					<td colspan="2"><button type="submit" name="submit" value="" >Add Details</button></td>
                   
				</tr>
                <tr id="btna1">
					 <td colspan="2"><button type="reset" name="reset" value="" >Reset</button></td>
                   
				</tr>
                
			</tbody>
		</table>
        
      
        </form>
        <?php

if(isset($_POST['submit'])){
	
	

   $Patientname = mysqli_real_escape_string($conn, $_POST['Patientname']);
   $PatientGender = mysqli_real_escape_string($conn, $_POST['PatientGender']);
   $PatientAge = mysqli_real_escape_string($conn, $_POST['PatientAge']);  
   $PatientEmail = mysqli_real_escape_string($conn, $_POST['PatientEmail']);
   $PatientContact = mysqli_real_escape_string($conn, $_POST['PatientContact']);
   $PatientAddress = mysqli_real_escape_string($conn, $_POST['PatientAddress']);
   $blood_Group = mysqli_real_escape_string($conn, $_POST['blood_Group']);
   $username = mysqli_real_escape_string($conn, $_POST['username']);
  
   $password = md5($_POST['password']);
   
   
   if( $Patientname=="" && $PatientGender=="" && $PatientAge=="" && $PatientEmail=="" && $PatientContact=="" && $PatientAddress=="" && $blood_Group=="" && $username=="" && $password==""){
	   
	   echo '<script type="text/javascript"> alert("ERROR     : Please fill in the blanks  !!!!!!!!") </script>';
	   print"<font color='#FF0000'>Error     : Please fill in the blanks  !!!!!!!! ";
	
	}else{
   

 $insert = "INSERT INTO register(patient_name, gender, age, email,contact,address,blood_group,username,password) VALUES('$Patientname','$PatientGender','$PatientAge','$PatientEmail','$PatientContact','$PatientAddress','$blood_Group','$username', '$password')";
		 
         $result=mysqli_query($conn, $insert);
		 
		 if($result){
			echo"<font color='#009900'> Data regisiter Succesfully ";//important
	        echo"<br/>";
			echo '<script type="text/javascript"> alert("Data regisiter Succesfully") </script>';
		 }
		 else{
			echo '<script type="text/javascript"> alert("Data regisiter Unuccesfully") </script>';//important
			print"<font color='#FF0000'>Error    :   Data regisiter Unuccesfully !!!!!!!! ";
			 echo"<br/>";
		 }
	}
		 
         
}

?>
<br />
         </div>
    
        
            </div>
           
         
        
                <a href="p_home.html">
      <button type="button" name="submit" class="back" > back </button>
      
      </a>
        


    </center>

</body>

</html>