<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator Doctor Delete.php</title>
<link rel="stylesheet" href="show.css">




</head>


<body>



<center>


 <div class="image">
 <img src="images/22.jpeg" />

 </div>
 
 <div class="title">
 
 <h1> Welcome Administrator</h1>
 
  </div>
   <div class="sentences">
 
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca c  </p>
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafcsackas j </p>
 <p>cjasafcsackas jkc asj cjas cjas cja ca </p>

  </div>
   <div class="container">

  <div class="type">
<form method="post" action="Admin_Doc_Delete.php">

<h3>Delete Doctor Details :</h3>

Enter Doctor Uswername :

<input type="text" name="delete" id="delete" />
<br /><br />
<button type="submit" name="submit" class="delete"> Delete </button>
<a href="Admin_home.html">
<button type="button" name="submit" class="back"> back </button>
</a>

</form>



</div>

<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}

?>            

           
       </div>  

  
            <?php
				
				if(isset($_POST['submit'])){
					
						$delete_doc=$_POST['delete'];
						
							if($delete_doc==""){
							print"<font color='#FF0000'>Error    :   Please fill in the blank !!!!!!!! ";
							echo"<br/>";
						}
						else{								
						
						$sql="delete from doctor Where username='$delete_doc'";
						$result=mysqli_query($conn,$sql);
					if($result){
					echo '<script type="text/javascript"> alert("Data Deleted succesfully") </script>';
					echo"<font color='#009900'>Data Deleted succesfully  ";
				
					
					
				}
				else{
					print"<font color='#FF0000'>Error    :   Data Deleted Unsuccesfully!!!!!!!! ";
				    
				}
						}
					
						
						
						
						
						
			
					
				
				}
					
						
				
?>

 </center>


</body>
</html>