<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Doctor Appointments</title>

<link rel="stylesheet" href="show.css">


</head>

<body>


<center>


 <div class="image">
 <img src="images/22.jpeg" />
 </div>
 
 <div class="title">
 
 <h1>Welcome Administrator</h1>
 
  </div>
   <div class="sentences">
 
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafc </p>
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafcsa</p>
 <p>cjasafcsackas jkc asj cjas cjas cj </p>

  </div>
  
  <br />
  
        <form method="post">
    
      <h3>Enter Branch Name :</h3>
      <input type="text" placeholder="Search" name="search" />
      <button type="submit" name="br_doc" class="branch_s"> Search </button>
      <br />
      <br/>
      <h3>All Doctor Details :</h3>
      <button type="submit" name="all_doc" class="all_doc">  Click here </button>
      <a href="Admin_home.html">
<button type="button" name="all_doc" class="back"> back </button>
</a>
        
</form>



             	<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>

   <div class="container">

	
   

  <table class="table">
            
            <?php
				
				if(isset($_POST['br_doc'])){
					
						$search=$_POST['search'];
						
						if($search==""){
							print"<font color='#FF0000'>Error    :   Please fill in the blank !!!!!!!! ";
							echo"<br/>";
						}
						
						
						
						$sql="Select * from doctor Where branch='$search'";
						$result=mysqli_query($conn,$sql);
						
						if($result){
							if(mysqli_num_rows($result)>0) {
									echo '<thead class="name">
									<tr>									
									<th>Doctor Name</th>
				 	                <th>Specialization</th>
					                <th>Email</th>
                                    <th>Age</th>
				                 	<th>Contact</th>
                                    <th>Branch</th>
                                    <th>Address</th>
                                    <th>Fees</th>
									<th>Username</th>
									<th>Password</th>
									</tr>
									</thead>
									';
									
									while($row=mysqli_fetch_assoc($result)){
									echo '<tbody>;
									
									<tr>
															
									<td> '.$row['doctor_name'].' </td>
									<td> '.$row['specialization'].' </td>
									<td> '.$row['email'].' </td>
									<td> '.$row['age'].' </td>
									<td> '.$row['contact'].' </td>
									<td> '.$row['branch'].' </td>
									<td> '.$row['address'].' </td>
									<td> '.$row['fees'].' </td>
									<td> '.$row['username'].' </td>
									<td> '.$row['password'].' </td>
															
									</tr>
									
									</tbody>';
								}
								
								
							}else{
								
								print"<font color='#FF0000'>Error    :   Data not found !!!!!!!! ";
							}
							
							}else{
								
								print"<font color='#FF0000'>Error    :   Select the correct Database !!!!!!!! ";
							}
					}
			
			?>
			
			
			
			</table>
            
                 	
            <table class="table1">
            
            <?php
				
				if(isset($_POST['all_doc'])){
					
						
						$sql="Select * from doctor";
						$result=mysqli_query($conn,$sql);
						
						if($result){
							if(mysqli_num_rows($result)>0) {
									echo '<thead class="name">
									<tr>
										<th>Doctor Name</th>
				 	                <th>Specialization</th>
					                <th>Email</th>
                                    <th>Age</th>
				                 	<th>Contact</th>
                                    <th>Branch</th>
                                    <th>Address</th>
                                    <th>Fees</th>
									<th>Username</th>
									<th>Password</th>
									
									</tr>
									</thead>
									';
									
									while($row=mysqli_fetch_assoc($result)){
									echo '<tbody>;
									
									<tr>
									<td> '.$row['doctor_name'].' </td>
									<td> '.$row['specialization'].' </td>
									<td> '.$row['email'].' </td>
									<td> '.$row['age'].' </td>
									<td> '.$row['contact'].' </td>
									<td> '.$row['branch'].' </td>
									<td> '.$row['address'].' </td>
									<td> '.$row['fees'].' </td>
									<td> '.$row['username'].' </td>
									<td> '.$row['password'].' </td>
									</tr>
									
									</tbody>';
								}
								
							}else{
								
								print"<font color='#FF0000'>Error    :   Data not found !!!!!!!! ";
							}
							
							}else{
							print"<font color='#FF0000'>Error    :   Select the correct Database !!!!!!!! ";
								
							}
					}
			
			?>
			
			
			
			</table>
			



            
			</div>	

			
			</center>
            
            
					
        
    
 
</body>


</html>