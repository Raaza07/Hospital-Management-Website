<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator Patient Query.php</title>
<link rel="stylesheet" href="show.css">


</head>

<body>


<center>


 <div class="image">
 <img src="images/22.jpeg" />
 </div>
  
 <div class="title">
 
 <h1>Welcome Administrator</h1>
   <br />
  </div>
   <div class="sentences">
   
    <h2>Patient Query</h2>
   <br />
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca cjasafcsackas </p>
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca  </p>
 <p>cjasafcsackas jkc asj cjas cjas c </p>

  </div>
  
  <br />

  
  </center>
  
 <div class="container">
 
 <center>
 
 
 <div class="container"> 
	
    <form method="post">
    
      <h3>All Patient Querys </h3>
      <button type="submit" name="submit" class="query"> Click here </button>
      <a href="Admin_home.html">
<button type="button" name="submit" class="back"> back </button>
</a>
        
</form>
        <?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>
    <table class="table">
            
            <?php
				
				if(isset($_POST['submit'])){
					
						
						
						$sql="Select * from query";
						$result=mysqli_query($conn,$sql);
						
						if($result){
							if(mysqli_num_rows($result)>0) {
									echo '<thead class="name">
									<tr>									
								<th>Patient_Name</th>
					            <th>Email</th>
                                <th>Phone_Number</th>
								<th>Branch</th>
					            <th>Message</th>
									</tr>
									</thead>
									';
									
									while($row=mysqli_fetch_assoc($result)){
									echo '<tbody>;
									
									<tr>
															
									<td> '.$row['patient_name'].' </td>
									<td> '.$row['patient_email'].' </td>
									<td> '.$row['patient_contact'].' </td>
									<td> '.$row['patient_branch'].' </td>
									<td> '.$row['patient_message'].' </td>
									
															
									</tr>
									
									</tbody>';
								}
								
							}
							    else{
									print"<font color='#FF0000'>Error    :   Data not found !!!!!!!! ";
								
							        }
							
							}
							     else{
								print"<font color='#FF0000'>Error    :   Select the correct Database !!!!!!!! ";
								
							        }
					}
			
			?>
			
			
			
			</table>
			
</div>
			
			</center>
            
            
			</div>
			
        
    
 
</body>

</html>