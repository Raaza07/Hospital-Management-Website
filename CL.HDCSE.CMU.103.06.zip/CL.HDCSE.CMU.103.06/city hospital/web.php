<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>City Hospital</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">


    <!-- custom css file link  -->
    <link rel="stylesheet" href="front_home.css">

</head>
<body>




<!-- header section starts  -->

<header>

<a href="#" class="logo"><i class="fa fa-user-md"></i>City Hospital</a>

<nav class="navbar">
    <ul>
         <li><a href="#home" class="active">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#Doctors">Doctors</a></li>
        <li><a href="#Services">Services</a></li>
        <li><a href="#Laboratory"> Laboratory</a></li>
        <li><a href="#E-Channeling">E-Channeling</a></li>
        <li><a href="#review">Review</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>
</nav>

<div  class="fas fa-bars"></div>

</header>

<!-- header section ends -->


<!-- home section starts  -->

<section class="home" id="home">

<div class="content">
    <h1>Start Up Your Health Care </h1>
    <p>Every Day is a new opportunity for you to do something  for your health</p>
    <a href="#"><button>Explore</button></a>
</div>

<div class="box-container">

    <div class="box">
        <i class="fas fa-ambulance style=font-size:48px"></i>
        <h3>40+</h3>
        <p>Ambulance</p>
    </div>
    <div class="box">
        <i class="fa fa-user-md" style="font-size: 36px"></i>
        <h3>120+</h3>
        <p>Doctors at work</p>
    </div>
    

    <div class="box">
        <i class="fas fa-users" style="font-size:36px"></i>
        <h3>2000+</h3>
        <p>Happy Patients</p>
    </div>

    <div class="box">
        <i class="fas fa-bed" style="font-size:36px"></i>
        <h3>500+</h3>
        <p>Bed Facility</p>
    </div>

</div>

</section>

<!-- home section ends -->

<!-- about section starts  -->


<section class="about" id="about">

<h1 class="heading">about us</h1>
<h3 class="title">take care of your health with us</h3>

<div class="row">

    <div class="content">
        <h3>We Take Care Of Your Healthy Life</h3>
        <p>City Hospitals is the most accredited hospital in the Sri Lankan healthcare sector. Since 2008, City Hospitals has revolutionized the healthcare industry through infrastructure development and advancement of products and services, with a view to deliver healthcare that is on par with global medical standards.</p>
        <a href="#"><button>learn more</button></a>
    </div>

    <div class="image">
        <img src='images/OIP (3).jpeg' alt="">
    </div>

</div>

</section>

<!-- about section ends -->

<!-- Doctors section starts  -->

<section id="Doctors" class="Doctors">

<h1 class="heading">our Doctors</h1>
<h3 class="title">meet professional Doctors</h3>

<div class="card-container">

    <div class="card">
        <img src="images/1.jpeg" alt="">
        <h3>Dr. Silva</h3>
        <p>Senior Doctor</p>
        <div class="icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-github"></a>
        </div>
    </div>

    <div class="card">
        <img src="images/2.jpg" alt="">
        <h3>Dr. Chanuka Perera</h3>
        <p>Ophthalmologists</p>
        <div class="icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-github"></a>
        </div>
    </div>

    <div class="card">
        <img src="images/3.jpeg" alt="">
        <h3>Dr. Maheshani Rajapakshe</h3>
        <p>Heart Specialist</p>
        <div class="icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-github"></a>
        </div>
    </div>

    <div class="card">
        <img src="images/R.jpeg" alt="">
        <h3>Dr. Kaanthi Vijayalakshmi</h3>
        <p>Neurologist</p>
        <div class="icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-github"></a>
        </div>
    </div>
    
       <div class="card">
        <img src="images/4.webp" alt="">
        <h3>Dr. Jayani Fernando</h3>
        <p>Psychiatrists</p>
        <div class="icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-github"></a>
        </div>
    </div>
    
       <div class="card">
        <img src="images/OIP.jpeg" alt="">
        <h3>Dr. Dinithi Madushika</h3>
        <p>Cardiologists</p>
        <div class="icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-github"></a>
        </div>
    </div>

</div>


</section>

<!-- Doctors section ends -->

<!-- Services section starts  -->

<section id="Services" class="Services">

<h1 class="heading">our Services</h1>
<h3 class="title">We Provide Best Medical Services</h3>


<div class="box-container">

    <div class="box">
        <i class="fas fa-medkit style=font-size:48px"></i>
        <h3>EMERGENCY SERVICES</h3>
			<p>On call 24 hours a day, 7 days a week, Lanka Hospitals is possibly Sri Lanka’s best choice for treatment in a medical emergency, as we offer minimal waiting times and a dedicated unit of experienced doctors of all specialities of medicine.</p>
                <a href="#"><button>View more</button></a>
      
    </div>

    <div class="box">
        <i class="fas fa-ambulance style= font-size:48px"></i>
        <h3>24/7 Amubulance</h3>
        <p>we are fully equipped to handle any medical emergency or accident, with our 24-hour accident and emergency unit and ambulance service.</p>
            <a href="#"><button>View more</button></a>
    </div>

    <div class="box">
       <i class="fas fa-user-md style= font-size:48px"></i>
       <h3>KIDNEY CARE CENTER</h3>
			<p>We offer comprehensive and specialized care for kidney diseases, with dialysis and kidney transplants performed by the best and most respected nephrologists in the country.</p>
                <a href="#"><button>View more</button></a>
       
    </div>

    <div class="box">
        <i class="fas fa-bed" style="font-size:48px"></i>
        <h3>UROLOGY Care center </h3>
			<p>The Urology Care Centre is the first dedicated one-stop centre for urology in Sri Lanka. The main advantage of this centre is that patients can be assessed and can undergo a range of investigations during a single visit.</p>
                <a href="#"><button>View more</button></a>
       
    </div>

    <div class="box">
        <i class="fas fa-heartbeat style= font-size:48px"></i>
        <h3>Medical Services</h3>
		<p>For us service excellence is dynamic, which is why we constantly seek to enhance our service delivery in a bid to<br>provide our customers with world-care healthcare experiences.</p>
            <a href="#"><button>View more</button></a>
      
    </div>

    <div class="box">
       <i class="fas fa-stethoscope style= font-size:48px"></i>
        <h3>Free Checkups</h3>
      <p>Welcome to our free medical checkup page, where we offer comprehensive health assessments to help you stay on top of your well-being. Regular medical checkups are essential for maintaining good health, as they can help detect health issues early on, before they become more serious and harder to treat.</p>
          <a href="#"><button>View more</button></a>
    </div>

</div>

</section>

<!-- Services section ends -->

<!-- Laboratory section starts  -->

<section id="Laboratory" class="Laboratory">

<h1 class="heading">Laboratory Services</h1>
<h3 class="title">We Provide Best Laboratory Services</h3>


<div class="box-container">

    <div class="box">
       
        <h3>Angiography</h3>
				<p>X-ray examination of arteries and veins with a contrast medium to differentiate them from surrounding organs. The contrast medium is introduced through.....</p>
                <a href="#"><button>View more</button></a>
      
    </div>

    <div class="box">
        
        <h3>CT Scanning</h3>
				<p>Toshiba Aquilion one is able to routinely scan at 0.275 second scan speed and provides excellent motion-free images of an entire organ in one rotation.....</p>
                   <a href="#"><button>View more</button></a>
    </div>

    <div class="box">
   
       <h3>Exercise ECG</h3>
	   <p>he patient undergoes a standardized (Bruce) protocol on increasing exercise with continuous 12 lead ECG and blood preasure monitoring and watches....</p>
          <a href="#"><button>View more</button></a>
       
    </div>

    <div class="box">
       
       <h3>Fibro Scan</h3>
				<p>Examination with FibroScan®, also called transient elastography, is a technique used to assess liver stiffness without invasive investigation.....</p>
                   <a href="#"><button>View more</button></a>
       
    </div>

    <div class="box">
        
        <h3>M.R.I Scanning</h3>
				<p>M.R.I. means Magnetic resonance imaging which is a type of scan that uses strong magnetic fields and radio waves to produce.....</p>
                   <a href="#"><button>View more</button></a>
				
      
    </div>

    <div class="box">
       
       <h3>Opthalmology Clinic</h3>
				<p>One of the most advanced laser vision correction procedures available in the world. To treat nearsightedness, farsightedness.....</p>
                   <a href="#"><button>View more</button></a>
				    </div>

</div>

</section>

<!-- Laboratory section ends -->


<!-- Appoiments section starts  -->

<section id="E-Channeling" class="Appoiments">

<h1 class="heading">Appointments</h1>
<h3 class="title">Make Appointments</h3>

<div class="card-container">


    <div class="card">
    
    
    
<div class="form-container">

   <form name="patientform" method="post" action="login.php">
   
      <h3>Patient Login</h3>
      <br>
     </br>
        
  <h2>Username : <input type="text" name="username" required placeholder="enter your email"></h2> <br>
  
  <h2>Password : <input type="password" name="password" required placeholder="enter your password" > </h2><br>
  
      <input type="submit" name="submit" value="login now" class="form-btn" >
      
      
      <br>
     </br> 
       <br>
     </br>
       <br>
     </br>
      <p>don't have an account? <a href="Register.php">register now</a></p>
      
                   	<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>
   </form>
   
   
   
   
   

</div>

       </div>

    <div class="card">
           
    
<div class="form-container">

   <form name="doctorform" method="post" action="login.php">
   
      <h3>Doctor Login</h3>
    
  <h2>Username : <input type="text" name="username" required placeholder="enter your username"></h2> <br>
  
  <h2>Password : <input type="password" name="password" required placeholder="enter your password"> </h2><br>
  
      <input type="submit" name="btn_doc" value="login now" class="form-btn" >
     
   </form>
                	<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>
</div>

    </div>

    <div class="card">
           
    
<div class="form-container">

   <form name="adminform" method="post" action="login.php">
   
      <h3>Admin Login</h3>
      
     <h2>Username : <input type="text" name="username" required placeholder="enter your username"></h2> <br>
  
     <h2>Password : <input type="password" name="password" required placeholder="enter your password"> </h2><br>
  
      <input type="submit" name="btn_adm" value="login now" class="form-btn" >
     
   </form>


</div>

    </div>

</div>


</section>
<!-- Appoiments section ends -->







<!-- review section starts  -->

<section id="review" class="review">

<h1 class="heading">Patients Review</h1>
<h3 class="title">what our Patients says about us</h3>

<div class="box-container">

    <div class="box">
        <img src="images/6.jpeg" alt="">
        <h3>A.Amara Perera</h3>
        <p>Exceeded expectations. Good medical services and good room facilities in premium room. Nursing staff and sister were good and friendly except few old and colds.</p>
        <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
    
     <div class="box">
        <img src="images/7.jpeg" alt="">
        <h3>M.Gamage</h3>
        <p>Very spacious hospital with  a calm ambiance with soothing piped music . No overcrowding. Staff dressed in unique coloured uniforms and very pleasant in providing service.</p>
        <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>

    <div class="box">
        <img src="images/8.jpg" alt="">
        <h3>N.Vihaga Siriwardana</h3>
        <p>Special thanks to Consutant Surgeon Dr. Mahanama Gunasekara and  Consultant Anesthetist Dr. Ranmalee Kulasiri  for kind and friendly proceedings with my ailment.</p>
        <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>

    <div class="box">
        <img src="images/9.jpeg" alt="">
        <h3>S.P.Hettiarachchi</h3>
        <p>The hospital is nice and clean and the doctors and staff are caring. There wasn't much crowd on the day of my visit so you can get your medical requirements without much hassle.</p>
        <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
        </div>
    </div>

</div>

</section>

<!-- review section ends -->

<!-- contact section starts  -->

<section class="contact" id="contact">

<h1 class="ccc">contact us</h1>
<h3 class="title">we love conversatios, lets talk.</h3>

<div class="row">

    <div class="image">
        <img src="images/R (2).jpeg" alt="">
    </div>

    <div class="form-container">
        <form method="post" action="query_W.php">
            <input type="text" name="P_name" placeholder="full name">
            <input type="email" name="p_email" placeholder="enter your email">
            <input type="number" name="p_contact" placeholder="phone">
             <input type="text" name="p_branch" placeholder="Branch name">
            <textarea name="p_message" id="" cols="30" rows="10" placeholder="message"></textarea>
            <input type="submit"  name="submit" value="message">
        </form>
    </div>

</div>

</section>

<!-- contact section ends -->

<section class="footer">

<div class="icons">
    <a href="#" class="fab fa-facebook-f"></a>
    <a href="#" class="fab fa-twitter"></a>
    <a href="#" class="fab fa-instagram"></a>
    <a href="#" class="fab fa-github"></a>
    <a href="#" class="fab fa-pinterest"></a>
</div>

<div class="credit">created by <span>mr. Abdul Razzak</span> </div>

</section>














<!-- jquery cdn link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- custom js file link  -->
<script src="front_home.js"></script>

    
</body>
</html>