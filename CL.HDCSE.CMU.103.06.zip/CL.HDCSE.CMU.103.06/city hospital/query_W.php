<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');


?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<?php

if(isset($_POST['submit'])){

   $P_name = mysqli_real_escape_string($conn, $_POST['P_name']);
   $p_email = mysqli_real_escape_string($conn, $_POST['p_email']);
   $p_contact = mysqli_real_escape_string($conn, $_POST['p_contact']);  
   $p_branch = mysqli_real_escape_string($conn, $_POST['p_branch']);
   $p_message = mysqli_real_escape_string($conn, $_POST['p_message']);
 

 

   

 $insert = "INSERT INTO query(patient_name, patient_email, patient_contact, patient_branch,patient_message) VALUES('$P_name','$p_email','$p_contact','$p_branch','$p_message')";
		 
         $result=mysqli_query($conn, $insert);
		 
		 if($result){
			echo "Query data added Succesfully"; 
			echo '<script type="text/javascript"> alert("Query data added Succesfully"") </script>';
		 }
		 else{
			 
			 echo "Query data added  UnSuccesfully"; 
		 }
		 
		 
         
}

?>



<body>
</body>
</html>