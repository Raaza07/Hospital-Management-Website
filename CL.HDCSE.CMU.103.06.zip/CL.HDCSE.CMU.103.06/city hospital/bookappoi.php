
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>book appointment</title>

<link rel="stylesheet" href="regCss.css">

</head>
	
  
<body>



<center>

 
 <div class="image">
 <img src="images/22.jpeg" />
 </div>
 
 
 <div class="title">
 
 <h2>Book Appointment</h2>
 
  </div>
 
 <div class="sentences">
 
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca  </p>
 <p>asjasbcasbckjas cjas cjas cj asjca cja cja cjas ca  </p>
 <p>cjasafcsackas jkc asj cjas cjas cja casj cjas casj casj ca </p>

  </div>
  <br />
  
   	<?php
	
	
$conn = mysqli_connect('localhost','root','','pa_register');//important

if(!$conn){
	die('Could not connect : ' .mysqli_error($conn));
	
}
if($conn){
	
	echo"<font color='#009900'> Database connected succsesfully  ";
	echo"<br/>";
	
}


?>
  
  
<br />

<div class="tab1">
		<table border="4">
			<thead>
				<tr>
					<th>Specialization </th>
                    
					<td>
                    
                    <form name="form" method="post" action="">
                    
                    <select id="Specialization" name="Specialization">
                    
                    <option value="Specialty doctors ">Specialty doctors </option>
                    <option value="Allergists">Allergists</option>
                    <option value="Dermatologists">Dermatologists</option>
                    <option value="Ophthalmologists">Ophthalmologists</option>
                    <option value="Cardiologists">Cardiologists</option>
                    <option value="Endocrinologists">Endocrinologists</option>
                    <option value="Psychiatrists">Psychiatrists</option>
                    
                          </select>                
                    
                    </td>
				</tr>
			</thead>
			<tbody>
            
				<tr>
					<th>Doctors</th>
					<td>
                    
                    <select id="doctors" name="doctors">
                    
                    <option value="Dr.Amal (Specialty doctors)">Dr.Amal (Specialty doctors)</option>
                    <option value="Dr.vihaga (Dermatologists)">Dr.vihag (Dermatologists)a</option>
                    <option value="Dr.kanthi (Allergists)">Dr.kanthi (Allergists)</option>
                    <option value="Dr.prera (Cardiologists)">Dr.prera (Cardiologists)</option>
                    <option value="Dr.aakila kalam (Psychiatrists)">Dr.aakila kalam (Psychiatrists)</option>
                    <option value="Dr.manoj (Endocrinologists)">Dr.manoj(Endocrinologists)</option>
                    <option value="Dr.mohomed malik (Ophthalmologists)">Dr.mohomed malik (Ophthalmologists)</option>
                    
                          </select>  
                    
                    
                    </td>
				</tr>
				<tr>
					<th>Appointment Date</th>
					<td><input type="date" name="date" id="date"></td>
				</tr>
				<tr>
					<th>Appointment Time</th>
					<td><input type="time" name="time" id="time"></td>
				</tr>
                
                <tr>
					<th>Branch</th>
					<td>
                    
                    <select id="Branch" name="branch">
                    
                    <option value="Jaffna">Jaffna</option>
                    <option value="Galle">Galle</option>
                    <option value="Kurunagala">Kurunagala</option>
                    
                    
                          </select>  
                    
                    
                    </td>
				</tr>
                
                  <tr>
					<th>Patient Name</th>
					<td>
                    
          <input type="text" name="Patient" id="Patient">
                    
                    
                    </td>
				</tr>
                
                  <tr>
					<th>Gender</th>
					<td>
                    
                    <select id="Gender" name="gender">
                    
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                 
                    
                          </select>  
                    
                    
                    </td>
				</tr>
                         <tr>
					<th>Patient Email</th>
					<td>
                    
          <input type="text" name="Email" id="Email">
                    
                    
                    </td>
				</tr>
                
                
				<tr id="btna">
					<td colspan="2"><input type="submit" name="submit" id="btn" value="Add details" onclick="AddRow()"></td>
				</tr>
                <tr id="btna">
					<td colspan="2"><input type="reset" name="reset" id="btn" value="Clear details " onclick="AddRow()"></td>
				</tr>
                
			</tbody>
		</table>
         </div>
         </form>
         <br />
          <?php

if(isset($_POST['submit'])){
	
	

   $Specialization = mysqli_real_escape_string($conn, $_POST['Specialization']);
   $doctors = mysqli_real_escape_string($conn, $_POST['doctors']);
   $date = mysqli_real_escape_string($conn, $_POST['date']);  
   $time = mysqli_real_escape_string($conn, $_POST['time']);
   $branch = mysqli_real_escape_string($conn, $_POST['branch']);
   $Patient = mysqli_real_escape_string($conn, $_POST['Patient']);
   $gender = mysqli_real_escape_string($conn, $_POST['gender']);
   $Email = mysqli_real_escape_string($conn, $_POST['Email']);
  
  
   

 $insert = "INSERT INTO appointments(specialization, doctors, date, time	,branch,Patient_name,gender,email) VALUES('$Specialization','$doctors','$date','$time','$branch','$Patient','$gender','$Email')";
		 
         $result=mysqli_query($conn, $insert);
		 
		 if($result){
			echo"<font color='#009900'> Appointment Details Added Succesfully ";//important
	        echo"<br/>";
			echo '<script type="text/javascript"> alert("Appointment Details Added Succesfully ") </script>';
		 }
		 else{
			echo '<script type="text/javascript"> alert("Data regisiter Unuccesfully") </script>';//important
			print"<font color='#FF0000'>Error    :  Appointment Details Added Unsuccesfully  !!!!!!!! ";
			echo"<br/>";
		 }
	}
		 
         

?>

    
       
       
          <a href="Patient_home.html">
      <button type="button" name="submit" class="back" > back </button>
      
      </a>
        
	</center>
    <div>
         
      
</body>
</html>