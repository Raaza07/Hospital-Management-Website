-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 28, 2023 at 09:40 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pa_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE IF NOT EXISTS `appointments` (
  `specialization` varchar(20) NOT NULL,
  `doctors` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `Patient_name` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`specialization`, `doctors`, `date`, `time`, `branch`, `Patient_name`, `gender`, `email`) VALUES
('Allergists', 'Dr.kanthi (Allergist', '2023-03-02', '13:33', 'Galle', 'abdul razzak', 'Male', 'abdullraz07@gmail.co');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE IF NOT EXISTS `doctor` (
  `doctor_name` varchar(20) NOT NULL,
  `specialization` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `age` int NOT NULL,
  `contact` int NOT NULL,
  `branch` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `fees` int NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_name`, `specialization`, `email`, `age`, `contact`, `branch`, `address`, `fees`, `username`, `password`) VALUES
('dr.amal', 'Allergists', 'abdullraz07@gmail.co', 30, 767605139, 'Jaffna', '585/1basline road de', 10000, 'doctor', '123');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

DROP TABLE IF EXISTS `query`;
CREATE TABLE IF NOT EXISTS `query` (
  `patient_name` varchar(20) NOT NULL,
  `patient_email` varchar(20) NOT NULL,
  `patient_contact` int NOT NULL,
  `patient_branch` varchar(20) NOT NULL,
  `patient_message` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`patient_name`, `patient_email`, `patient_contact`, `patient_branch`, `patient_message`) VALUES
('abdul razzak', 'abdullraz07@gmail.co', 767605139, 'jaffna', 'i love you');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `patient_name` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `age` int NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` int NOT NULL,
  `address` varchar(20) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`patient_name`, `gender`, `age`, `email`, `contact`, `address`, `blood_group`, `username`, `password`) VALUES
('abdul razzak', 'male', 21, 'abdullraz07@gmail.co', 767605139, '585l1 basline road d', 'o+', 'abdulrazzak', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
